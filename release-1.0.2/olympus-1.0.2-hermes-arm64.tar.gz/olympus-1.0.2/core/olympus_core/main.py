from contextlib import asynccontextmanager
import asyncio
from datetime import datetime, timezone
import logging

from fastapi import FastAPI, WebSocket

from olympus_core.agents.registry import AgentRegistry
from olympus_core.config import SpotifySettings, load_core_config
from olympus_core.display.hub import DisplayHub
from olympus_core.display.static import install_display_routes
from olympus_core.integrations.spotify import SpotifyApi, SpotifyCollector
from olympus_core.integrations.weather import OpenMeteoApi, WeatherCollector
from olympus_core.integrations.calendar import CalendarCollector, GoogleCalendarApi
from olympus_core.integrations.football import FootballCollector, create_football_provider
from olympus_core.integrations.news import FixtureNewsProvider, NewsCollector, RssNewsProvider
from olympus_core.monitoring.config import load_monitoring_config
from olympus_core.monitoring.runtime import MonitoringRuntime
from olympus_core.release import release_info
from olympus_core.models.agent import RegisteredAgent
from olympus_core.models.media import MediaState
from olympus_core.models.gameplay import GameplayEvent
from olympus_core.models.weather import WeatherState
from olympus_core.models.calendar import CalendarSnapshot
from olympus_core.models.football import FootballDisplayEvent, FootballState
from olympus_core.models.news import NewsDisplayEvent, NewsState
from olympus_core.models.state import OlympusState
from olympus_core.persistence.database import Database
from olympus_core.persistence.devices import DeviceRepository
from olympus_core.persistence.enrollment import EnrollmentRepository
from olympus_core.persistence.incidents import IncidentRepository
from olympus_core.persistence.news_memory import NewsMemoryRepository
from olympus_core.services.media import MediaStateStore
from olympus_core.services.events import EventService
from olympus_core.services.monitoring_store import MonitoringStore
from olympus_core.services.state import StateService
from olympus_core.services.gameplay import GameplayEventService
from olympus_core.services.ambient import CalendarStateStore, WeatherStateStore
from olympus_core.services.time_policy import TimePolicyService
from olympus_core.services.football import FootballStateStore
from olympus_core.services.news import NewsStateStore
from olympus_core.websocket.agents import handle_agent_socket
from olympus_core.websocket.display import handle_display_socket


logger = logging.getLogger(__name__)
registry = AgentRegistry()
core_settings = load_core_config()
database = Database(core_settings.persistence.resolved_database_path)
device_repository = DeviceRepository(database)
enrollment_repository = EnrollmentRepository(
    database, core_settings.security.enrollment_token_ttl_minutes
)
incident_repository = IncidentRepository(database)
news_memory_repository = NewsMemoryRepository(database)
media_store = MediaStateStore()
weather_store = WeatherStateStore()
calendar_store = CalendarStateStore(core_settings.timezone)
football_store = FootballStateStore()
news_store = NewsStateStore()
time_policy_service = TimePolicyService(core_settings.night, core_settings.timezone)
monitoring_store = MonitoringStore()
event_service = EventService(incidents=incident_repository)
state_service = StateService(
    registry,
    media_store,
    monitoring=monitoring_store,
    events=event_service,
    timezone=core_settings.timezone,
    weather=weather_store,
    calendar=calendar_store,
    time_policy=time_policy_service,
    football=football_store,
    news=news_store,
)
display_hub = DisplayHub()
gameplay_service = GameplayEventService()


async def publish_display_state() -> None:
    await display_hub.broadcast(state_service.display_state())


async def update_media_state(media: MediaState) -> None:
    media_store.update(media)
    await publish_display_state()


async def update_weather_state(weather: WeatherState) -> None:
    weather_store.update(weather)
    await publish_display_state()


async def update_calendar_state(calendar: CalendarSnapshot) -> None:
    calendar_store.update(calendar)
    await publish_display_state()


async def update_football_state(football: FootballState) -> None:
    football_store.update(football)
    await publish_display_state()


async def update_news_state(news: NewsState) -> None:
    news_store.update(news)
    await publish_display_state()


async def publish_ambient_time_progression() -> None:
    while True:
        await asyncio.sleep(60)
        if calendar_store.has_state:
            await publish_display_state()


async def publish_time_policy_transitions() -> None:
    while True:
        policy = time_policy_service.evaluate()
        transition = policy.next_transition_at
        if transition is None:
            return
        delay = max(
            0.25,
            (transition.astimezone(timezone.utc) - datetime.now(timezone.utc)).total_seconds() + 0.05,
        )
        await asyncio.sleep(delay)
        await publish_display_state()


async def publish_gameplay_event(event: GameplayEvent) -> None:
    await display_hub.broadcast_event(event)


async def publish_football_event(event: FootballDisplayEvent) -> None:
    await display_hub.broadcast_event(event)


async def publish_news_event(event: NewsDisplayEvent) -> None:
    await display_hub.broadcast_event(event)


async def persistence_maintenance() -> None:
    while True:
        await asyncio.sleep(21_600)
        try:
            enrollment_repository.cleanup()
            incident_repository.cleanup(core_settings.persistence.incident_retention_days)
            news_memory_repository.cleanup(core_settings.persistence.news_memory_retention_days)
        except Exception as error:
            logger.warning("Persistence retention cleanup failed: %s", error)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    database.initialize()
    logger.info("Core persistence initialized")
    if not core_settings.security.require_agent_auth:
        logger.warning("Agent authentication is DISABLED. Use only for local development.")
    monitoring_config = load_monitoring_config()
    active_incident_keys: set[str] = {
        f"service:{service.id}" for service in monitoring_config.services
    }
    if monitoring_config.network.enabled:
        active_incident_keys.update({
            "network:gateway", "network:internet", "network:dns", "network:https"
        })
        active_incident_keys.update(
            f"network:target:{target.id}"
            for target in monitoring_config.network.targets
            if target.alert
        )
    event_service.restore(active_incident_keys)
    enrollment_repository.cleanup()
    incident_repository.cleanup(core_settings.persistence.incident_retention_days)
    news_memory_repository.cleanup(core_settings.persistence.news_memory_retention_days)
    maintenance_task = asyncio.create_task(
        persistence_maintenance(), name="persistence-maintenance"
    )
    monitoring = MonitoringRuntime(
        monitoring_config,
        monitoring_store,
        event_service,
        publish_display_state,
    )
    monitoring.start()
    time_policy_task: asyncio.Task[None] | None = None
    if core_settings.night.enabled:
        time_policy_task = asyncio.create_task(
            publish_time_policy_transitions(), name="time-policy-transitions"
        )
    settings = SpotifySettings.from_environment()
    collector: SpotifyCollector | None = None
    collector_task: asyncio.Task[None] | None = None
    if settings.enabled and settings.has_credentials:
        collector = SpotifyCollector(
            settings,
            SpotifyApi(settings),
            update_media_state,
        )
        collector_task = asyncio.create_task(
            collector.run(), name="spotify-collector"
        )
    elif settings.enabled:
        logger.warning(
            "Spotify collector disabled because credentials are incomplete"
        )
    else:
        logger.info("Spotify collector disabled")

    weather_collector: WeatherCollector | None = None
    weather_task: asyncio.Task[None] | None = None
    if core_settings.weather.configured:
        weather_collector = WeatherCollector(
            core_settings.weather,
            OpenMeteoApi(core_settings.weather),
            update_weather_state,
        )
        weather_task = asyncio.create_task(
            weather_collector.run(), name="weather-collector"
        )
    elif core_settings.weather.enabled:
        logger.warning("Weather collector disabled because coordinates are invalid or missing")
    else:
        logger.info("Weather collector disabled")

    calendar_collector: CalendarCollector | None = None
    calendar_task: asyncio.Task[None] | None = None
    ambient_tick_task: asyncio.Task[None] | None = None
    if core_settings.calendar.configured:
        calendar_collector = CalendarCollector(
            core_settings.calendar,
            GoogleCalendarApi(core_settings.calendar),
            update_calendar_state,
        )
        calendar_task = asyncio.create_task(
            calendar_collector.run(), name="calendar-collector"
        )
        ambient_tick_task = asyncio.create_task(
            publish_ambient_time_progression(), name="ambient-minute-tick"
        )
    elif core_settings.calendar.enabled:
        logger.warning("Calendar collector disabled because provider or credentials are incomplete")
    else:
        logger.info("Calendar collector disabled")

    football_collector: FootballCollector | None = None
    football_task: asyncio.Task[None] | None = None
    if core_settings.football.configured:
        football_provider = create_football_provider(core_settings.football)
        football_collector = FootballCollector(
            core_settings.football,
            football_provider,
            update_football_state,
            publish_football_event,
        )
        football_task = asyncio.create_task(
            football_collector.run(), name="football-collector"
        )
    elif core_settings.football.enabled:
        logger.error(
            "Football collector disabled: %s",
            core_settings.football.configuration_issue or "configuration is incomplete",
        )
    else:
        logger.info("Football collector disabled")

    news_collector: NewsCollector | None = None
    news_task: asyncio.Task[None] | None = None
    if core_settings.news.configured:
        news_provider = (
            FixtureNewsProvider(core_settings.news)
            if core_settings.news.provider == "fixture"
            else RssNewsProvider(core_settings.news)
        )
        news_collector = NewsCollector(
            core_settings.news,
            news_provider,
            update_news_state,
            publish_news_event,
            news_memory_repository,
            core_settings.persistence.news_memory_retention_days,
        )
        news_task = asyncio.create_task(news_collector.run(), name="news-collector")
    elif core_settings.news.enabled:
        logger.warning("News collector disabled because no usable feeds or fixture are configured")
    else:
        logger.info("News collector disabled")

    try:
        yield
    finally:
        if collector is not None and collector_task is not None:
            collector.stop()
            await collector_task
        if weather_collector is not None and weather_task is not None:
            weather_collector.stop()
            await weather_task
        if calendar_collector is not None and calendar_task is not None:
            calendar_collector.stop()
            await calendar_task
        if ambient_tick_task is not None:
            ambient_tick_task.cancel()
            await asyncio.gather(ambient_tick_task, return_exceptions=True)
        if time_policy_task is not None:
            time_policy_task.cancel()
            await asyncio.gather(time_policy_task, return_exceptions=True)
        if football_collector is not None and football_task is not None:
            football_collector.stop()
            await football_task
        if news_collector is not None and news_task is not None:
            news_collector.stop()
            await news_task
        await monitoring.stop()
        maintenance_task.cancel()
        await asyncio.gather(maintenance_task, return_exceptions=True)
        database.close()


RELEASE = release_info()


app = FastAPI(
    title="Olympus Core",
    description="Core service for the Olympus home display system.",
    version=RELEASE.version,
    lifespan=lifespan,
)


@app.get("/health")
async def health() -> dict[str, str]:
    release = release_info()
    return {
        "status": "ok",
        "service": "olympus-core",
        "version": release.version,
        "revision": release.revision,
        "source_tree": release.source_tree,
        "persistence": "healthy" if database.available else "unavailable",
    }


@app.get("/api/agents", response_model=list[RegisteredAgent])
async def agents() -> list[RegisteredAgent]:
    return registry.get_all()


@app.get("/api/state", response_model=OlympusState)
async def state() -> OlympusState:
    return state_service.current()


@app.websocket("/ws/agents")
async def agent_socket(websocket: WebSocket) -> None:
    await handle_agent_socket(
        websocket,
        registry,
        publish_display_state,
        publish_gameplay_event,
        gameplay_service,
        core_settings.security,
        device_repository,
        enrollment_repository,
    )


@app.websocket("/ws/display")
async def display_socket(websocket: WebSocket) -> None:
    await handle_display_socket(websocket, display_hub, state_service)


install_display_routes(app, core_settings.display.resolved_directory)
